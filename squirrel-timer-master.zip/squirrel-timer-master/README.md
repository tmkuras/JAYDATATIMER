# squirrel-timer
Simple timer dashboard for recording animal behavior
